<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Pr&oacute;ximamente');

define('TABLE_HEADING_PRODUCTS', 'Productos');
define('TABLE_HEADING_DATE_EXPECTED', 'Fecha Lanzamiento');
define('TABLE_HEADING_ACTION', 'Acci&oacute;n');

define('TEXT_INFO_DATE_EXPECTED', 'Fecha Lanzamiento:');
?>