<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_TITLE', 'Ultimos Add-Ons');
define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_DESCRIPTION', 'Mostrar los &uacute;ltimos Add-Ons');
define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_DATE', 'Fecha');
define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_FEED_ERROR', 'No se pudo conectar al osCommerce Add-Ons. El siguiente intento se llevar&aacute; a cabo dentro de las 24 horas.');
define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_ICON_RSS', 'Suscr&iacute;base a Add-Ons en osCommerce Feed RSS');
?>
