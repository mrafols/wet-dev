<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_TOTAL_REVENUE_TITLE', 'Tabla de Ingreso Total (&uacute;ltimos 30 d&iacute;as)');
define('MODULE_ADMIN_DASHBOARD_TOTAL_REVENUE_DESCRIPTION', 'Mostrar el gr&aacute;fico del Ingreso Total de los &uacute;ltimos 30 d&iacute;as');
define('MODULE_ADMIN_DASHBOARD_TOTAL_REVENUE_CHART_LINK', 'Ingreso Total');
?>
