<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_SECURITY_CHECKS_TITLE', 'Controles de Seguridad');
define('MODULE_ADMIN_DASHBOARD_SECURITY_CHECKS_DESCRIPTION', 'Ejecutar controles de Seguridad');
define('MODULE_ADMIN_DASHBOARD_SECURITY_CHECKS_SUCCESS', 'Es una instalaci&oacute;n correctamente configurada de osCommerce Online Merchant!');
?>
