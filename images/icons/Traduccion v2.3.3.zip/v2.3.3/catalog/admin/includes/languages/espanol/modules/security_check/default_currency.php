<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('ERROR_NO_DEFAULT_CURRENCY_DEFINED', 'Error: No existe actualmente ning&uacute;n conjunto de moneda predeterminado. Por favor, establecer uno en: Herramienta de Administraci&oacute;n->Localizaci&oacute;n->Monedas');
?>
