<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_ADMIN_LOGINS_TITLE', 'Ultimas conexi&oacute;n del Administrador');
define('MODULE_ADMIN_DASHBOARD_ADMIN_LOGINS_DESCRIPTION', 'Mostrar los &uacute;ltimos inicios de sesi&oacute;n exitosos y fallidos del Administrador');
define('MODULE_ADMIN_DASHBOARD_ADMIN_LOGINS_DATE', 'Fecha');
?>
