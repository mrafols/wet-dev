<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_TITLE', 'Verificar Versi&oacute;n');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_DESCRIPTION', 'Mostrar resultado de la verificaci&oacute;n de la versi&oacute;n');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_DATE', 'Ultima verificaci&oacute;n activada');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_CHECK_NOW', 'Verificar ahora');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_NEVER', 'Nunca');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_UPDATE_AVAILABLE', 'Una actualizaci&oacute;n de osCommerce Online Merchant est&aacute; disponible!');
?>
