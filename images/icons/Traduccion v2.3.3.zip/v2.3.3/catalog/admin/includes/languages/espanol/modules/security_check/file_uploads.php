<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('WARNING_FILE_UPLOADS_DISABLED', 'Advertencia: La carga de archivos est&aacute; desactivado en el archivo de configuraci&oacute;n php.ini.');
?>
