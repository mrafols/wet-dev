<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Grabadora de acciones');

define('TABLE_HEADING_MODULE', 'M&oacute;dulo');
define('TABLE_HEADING_CUSTOMER', 'Cliente');
define('TABLE_HEADING_DATE_ADDED', 'Fecha');
define('TABLE_HEADING_ACTION', 'Acci&oacute;n');

define('TEXT_FILTER_SEARCH', 'Buscar:');
define('TEXT_ALL_MODULES', '-- Todos los M&oacute;dulos --');
define('TEXT_GUEST', 'Invitado');

define('TEXT_INFO_IDENTIFIER', 'Identificador:');
define('TEXT_INFO_DATE_ADDED', 'Fecha de Alta:');

define('SUCCESS_EXPIRED_ENTRIES', 'Exito: %s entradas vencidas se eliminaron.');
?>