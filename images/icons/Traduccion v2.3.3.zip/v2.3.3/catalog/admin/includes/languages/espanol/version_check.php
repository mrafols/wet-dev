<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Verificar Versi&oacute;n');

define('TABLE_HEADING_VERSION', 'Versi&oacute;n');
define('TABLE_HEADING_RELEASED', 'Fecha de la versi&oacute;n');
define('TABLE_HEADING_ACTION', 'Acci&oacute;n');

define('TEXT_RELEASE_LINK', 'Ver Anuncio de la versi&oacute;n');

define('TITLE_INSTALLED_VERSION', 'Versi&oacute;n Instalada:');

define('VERSION_RUNNING_LATEST', 'Se est&aacute; ejecutando la &uacute;ltima versi&oacute;n de osCommerce Online Merchant.');
define('VERSION_UPGRADES_AVAILABLE', 'Una nueva versi&oacute;n esta disponible para su descarga ! (osCommerce Online Merchant v%s)');

define('ERROR_COULD_NOT_CONNECT', 'No se pudo conectar al sitio web osCommerce para comprobar si hay nuevas versiones.');
?>