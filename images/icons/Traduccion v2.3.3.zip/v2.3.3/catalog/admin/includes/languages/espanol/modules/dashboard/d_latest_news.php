<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_TITLE', 'Ultimas Noticias');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_DESCRIPTION', 'Mostrar las &uacute;ltimas noticias de osCommerce');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_DATE', 'Fecha');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_FEED_ERROR', 'No se pudo conectar a la fuente de noticias osCommerce. El siguiente intento se llevar&aacute; a cabo dentro de las 24 horas.');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_NEWSLETTER', 'Inscr&iacute;base para recibir el bolet&iacute;n osCommerce');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_FACEBOOK', 'Convi&eacute;rtete en un Fan de osCommerce en Facebook');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_TWITTER', 'Seguir a osCommerce en Twitter');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_RSS', 'Suscr&iacute;base a las noticias de osCommerce con RSS Feed');
?>
