<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('ERROR_NO_DEFAULT_LANGUAGE_DEFINED', 'Error: No existe actualmente ning&uacute;n conjunto de idioma predeterminado. Por favor, configure una en: Herramienta de Administraci&oacute;n->Localizaci&oacute;n->Idiomas');
?>
