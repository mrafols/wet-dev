<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('TEXT_COUNT_CUSTOMERS', 'Los clientes que reciben bolet&iacute;n: %s');
?>