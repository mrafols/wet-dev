<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('TABLE_HEADING_MODULES', 'M&oacute;dulos');
define('TABLE_HEADING_SORT_ORDER', 'Orden');
define('TABLE_HEADING_ACTION', 'Acci&oacute;n');

define('TEXT_INFO_VERSION', 'Versi&oacute;n:');
define('TEXT_INFO_ONLINE_STATUS', 'Estado de conexi&oacute;n');
define('TEXT_INFO_API_VERSION', 'Versi&oacute;n de la API:');

define('TEXT_MODULE_DIRECTORY', 'Directorio de M&oacute;dulos:');
?>
