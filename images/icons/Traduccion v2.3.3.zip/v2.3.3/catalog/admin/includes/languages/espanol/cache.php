<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Control de Cach&eacute;');

define('TABLE_HEADING_CACHE', 'Paneles');
define('TABLE_HEADING_DATE_CREATED', 'Fecha de Creaci&oacute;n');
define('TABLE_HEADING_ACTION', 'Acci&oacute;n');

define('TEXT_FILE_DOES_NOT_EXIST', 'No existe fichero');
define('TEXT_CACHE_DIRECTORY', 'Directorio para la Cach&eacute;: ');

define('ERROR_CACHE_DIRECTORY_DOES_NOT_EXIST', 'Error: No existe el directorio para la cach&eacute;. Configurelo en configure.php.');
define('ERROR_CACHE_DIRECTORY_NOT_WRITEABLE', 'Error: No se ha podido escribir en el directorio para la cach&eacute;.');
?>
