<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SHIPPING_ZONES_TEXT_TITLE', 'Tarifas por Zona');
define('MODULE_SHIPPING_ZONES_TEXT_DESCRIPTION', 'Tarifas basadas en Zonas');
define('MODULE_SHIPPING_ZONES_TEXT_WAY', 'Env&iacute;o a');
define('MODULE_SHIPPING_ZONES_TEXT_UNITS', 'lb(s)');
define('MODULE_SHIPPING_ZONES_INVALID_ZONE', 'Env&iacute;os no disponibles para el pa&iacute;s seleccionado');
define('MODULE_SHIPPING_ZONES_UNDEFINED_RATE', 'La tarifa de env&iacute;o no se puede determinar en este momento');
?>
