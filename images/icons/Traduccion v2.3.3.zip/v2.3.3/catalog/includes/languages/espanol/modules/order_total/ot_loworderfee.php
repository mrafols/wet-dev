<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ORDER_TOTAL_LOWORDERFEE_TITLE', 'Valor m&iacute;nimo del pedido');
  define('MODULE_ORDER_TOTAL_LOWORDERFEE_DESCRIPTION', 'Valor m&iacute;nimo del pedido');
?>