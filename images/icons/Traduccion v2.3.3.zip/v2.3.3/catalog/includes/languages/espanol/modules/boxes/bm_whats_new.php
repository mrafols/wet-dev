<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_WHATS_NEW_TITLE', 'Que es lo Nuevo');
  define('MODULE_BOXES_WHATS_NEW_DESCRIPTION', 'Mostrar los productos m&aacute;s nuevos');
  define('MODULE_BOXES_WHATS_NEW_BOX_TITLE', 'Que es lo Nuevo ?');
?>
