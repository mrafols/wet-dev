<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2012 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_CANONICAL_TITLE', 'Enlace de Cabecera Canonical');
  define('MODULE_HEADER_TAGS_CANONICAL_DESCRIPTION', 'Adicionar Enlace de Cabecera Canonical a categor&iacute;a y p&aacute;gina del producto');
?>
