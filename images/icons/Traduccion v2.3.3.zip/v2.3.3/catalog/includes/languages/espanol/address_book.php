<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Mi Cuenta');
define('NAVBAR_TITLE_2', 'Libreta de direcciones');

define('HEADING_TITLE', 'Mi Libreta de direcciones personal');

define('PRIMARY_ADDRESS_TITLE', 'Direcci&oacute;n Principal');
define('PRIMARY_ADDRESS_DESCRIPTION', 'Esta direcci&oacute;n se utiliza como los datos de env&iacute;o pre-seleccionado y la direcci&oacute;n de facturaci&oacute;n para los pedidos realizados en esta tienda.<br /><br />Esta direcci&oacute;n tambi&eacute;n se utiliza como la base para calcular los impuestos y servicio.');

define('ADDRESS_BOOK_TITLE', 'Entradas de la Libreta de direcciones');

define('PRIMARY_ADDRESS', '(direcci&oacute;n principal)');

define('TEXT_MAXIMUM_ENTRIES', '<font color="#ff0000"><b>NOTA:</b></font> Se permiten un m&aacute;ximo de %s direcciones.');
?>