<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Cont&aacute;ctenos');
define('NAVBAR_TITLE', 'Cont&aacute;ctenos');
define('TEXT_SUCCESS', 'Su consulta ha sido enviada al administrador de la Tienda.');
define('EMAIL_SUBJECT', 'Consulta desde ' . STORE_NAME);

define('ENTRY_NAME', 'Nombre Completo:');
define('ENTRY_EMAIL', 'Direcci&oacute;n de Correo Electr&oacute;nico:');
define('ENTRY_ENQUIRY', 'Consulta:');

define('ERROR_ACTION_RECORDER', 'Error: Una consulta ya ha sido enviada. Por favor vuelva a intentarlo en %s minutos.');
?>