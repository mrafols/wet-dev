<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2008 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_2CHECKOUT_TEXT_TITLE', '2Checkout');
  define('MODULE_PAYMENT_2CHECKOUT_TEXT_PUBLIC_TITLE', '2Checkout');
  define('MODULE_PAYMENT_2CHECKOUT_TEXT_PUBLIC_DESCRIPTION', 'Tarjetas de cr&eacute; y alternativas');
  define('MODULE_PAYMENT_2CHECKOUT_TEXT_DESCRIPTION', '<img src="images/icon_popup.gif" border="0">&nbsp;<a href="https://www.2checkout.com/2co/signup?affiliate=1255821" target="_blank" style="text-decoration: underline; font-weight: bold;">Visite el Sitio Web de 2Checkout</a>&nbsp;<a href="javascript:toggleDivBlock(\'pm2checkoutInfo\');">(info)</a><span id="pm2checkoutInfo" style="display: none;"><br /><i>Usando el enlace de arriba para registrarse en 2CheckOut subvenciona osCommerce con un peque&ntilde;o bono financiero por referir a un cliente.</i></span><br /><br />Informaci&oacute;n de Prueba de la tarjeta:<br /><br />CC#: 4111111111111111<br />Caducidad: Cualquiera');
  define('MODULE_PAYMENT_2CHECKOUT_TEXT_ERROR_MESSAGE', 'Se ha producido un error al procesar su tarjeta de cr&eacute;dito. Por favor, int&eacute;ntelo de nuevo.');
  define('MODULE_PAYMENT_2CHECKOUT_TEXT_WARNING_DEMO_MODE', 'En comentario: Transacci&oacute;n realizada en modo demostrativo.');
  define('MODULE_PAYMENT_2CHECKOUT_TEXT_WARNING_TRANSACTION_ORDER', 'En comentario: El total de la transacci&oacute;n no se ha encontrado en el pedido.');
?>