<?php
/*
  $Id: $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2009 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_SAGE_PAY_SERVER_TEXT_TITLE', 'Sage Pay Server');
  define('MODULE_PAYMENT_SAGE_PAY_SERVER_TEXT_PUBLIC_TITLE', 'Tarjeta de cr&eacute;dito o tarjeta bancaria (Procesado por Sage Pay)');
  define('MODULE_PAYMENT_SAGE_PAY_SERVER_TEXT_DESCRIPTION', '<img src="images/icon_popup.gif" border="0">&nbsp;<a href="https://support.sagepay.com/apply/default.aspx?PartnerID=C74D7B82-E9EB-4FBD-93DB-76F0F551C802&PromotionCode=osc223" target="_blank" style="text-decoration: underline; font-weight: bold;">Visit Sage Pay Website</a>&nbsp;<a href="javascript:toggleDivBlock(\'sagePayInfo\');">(info)</a><span id="sagePayInfo" style="display: none;"><br /><i>Usando el enlace de arriba para registrarse en Sage Pay subvenciona osCommerce con un peque&ntilde;o bono financiero por referir a un cliente.</i></span>');
  define('MODULE_PAYMENT_SAGE_PAY_SERVER_ERROR_TITLE', 'Se ha producido un error al procesar su transacci&oacute;n del pedido');
  define('MODULE_PAYMENT_SAGE_PAY_SERVER_ERROR_GENERAL', 'Por favor, int&eacute;ntelo de nuevo y si el problema persiste, pruebe otro m&eacute;todo de pago.');
?>
