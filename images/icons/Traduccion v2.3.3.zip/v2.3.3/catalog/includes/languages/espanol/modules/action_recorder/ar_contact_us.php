<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ACTION_RECORDER_CONTACT_US_TITLE', 'Cont&aacute;ctenos');
  define('MODULE_ACTION_RECORDER_CONTACT_US_DESCRIPTION', 'Registro del uso de la caracter&iacute;stica Cont&aacute;ctenos.');
?>
