<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_CATEGORY_TITLE_TITLE', 'T&iacute;tulo de la categor&iacute;a');
  define('MODULE_HEADER_TAGS_CATEGORY_TITLE_DESCRIPTION', 'Adicionar el t&iacute;tulo de la categor&iacute;a actual para el t&iacute;tulo de la p&aacute;gina');
?>
