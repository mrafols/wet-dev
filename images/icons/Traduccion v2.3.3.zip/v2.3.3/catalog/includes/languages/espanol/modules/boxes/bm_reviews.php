<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_REVIEWS_TITLE', 'Comentarios');
  define('MODULE_BOXES_REVIEWS_DESCRIPTION', 'Mostrar comentarios');
  define('MODULE_BOXES_REVIEWS_BOX_TITLE', 'Comentarios');
  define('MODULE_BOXES_REVIEWS_BOX_WRITE_REVIEW', 'Escribir un comentario de este producto!');
  define('MODULE_BOXES_REVIEWS_BOX_NO_REVIEWS', 'En este momento no hay ning&uacute;n comentario');
  define('MODULE_BOXES_REVIEWS_BOX_TEXT_OF_5_STARS', '%s de 5 Estrellas!');
?>
