<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ACTION_RECORDER_ADMIN_LOGIN_TITLE', 'Ingreso a la Herramienta de Administraci&oacute;n');
  define('MODULE_ACTION_RECORDER_ADMIN_LOGIN_DESCRIPTION', 'Registro de uso de los inicios de sesi&oacute;n de herramientas de administraci&oacute;n.');
?>
