<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_INFORMATION_TITLE', 'Informaci&oacute;n');
  define('MODULE_BOXES_INFORMATION_DESCRIPTION', 'Mostrar enlaces de informaci&oacute;n de p&aacute;gina');
  define('MODULE_BOXES_INFORMATION_BOX_TITLE', 'Informaci&oacute;n');
  define('MODULE_BOXES_INFORMATION_BOX_PRIVACY', 'Confidencialidad');
  define('MODULE_BOXES_INFORMATION_BOX_CONDITIONS', 'Condiciones de Uso');
  define('MODULE_BOXES_INFORMATION_BOX_SHIPPING', 'Env&iacute;os y Devoluciones');
  define('MODULE_BOXES_INFORMATION_BOX_CONTACT', 'Cont&aacute;ctenos');
?>
