<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2009 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_PAYPAL_PRO_PAYFLOW_EC_TEXT_TITLE', 'Sitio Web PayPal, Website Payments Pro (Payflow Edition) - Express Checkout');
  define('MODULE_PAYMENT_PAYPAL_PRO_PAYFLOW_EC_TEXT_PUBLIC_TITLE', 'PayPal (incluye tarjetas de cr&eacute;dito y d&eacute;bito)');
  define('MODULE_PAYMENT_PAYPAL_PRO_PAYFLOW_EC_TEXT_DESCRIPTION', '<strong>Nota: PayPal requiere el m&oacute;dulo de pago Payments Pro (Payflow Edition) - Direct Payments habilitado si este m&oacute;dulo esta activado.</strong><br /><br /><img src="images/icon_popup.gif" border="0">&nbsp;<a href="https://www.paypal.com/mrb/pal=PS2X9Q773CKG4" target="_blank" style="text-decoration: underline; font-weight: bold;">Visite el Sitio Web de PayPal</a>&nbsp;<a href="javascript:toggleDivBlock(\'paypalExpressUKInfo\');">(info)</a><span id="paypalExpressUKInfo" style="display: none;"><br /><i>Usando el enlace de arriba para registrarse en Paypal subvenciona osCommerce con un peque&ntilde;o bono financiero por referir a un cliente.</i></span>');
  define('MODULE_PAYMENT_PAYPAL_PRO_PAYFLOW_EC_TEXT_BUTTON', 'Pagar con PayPal');
  define('MODULE_PAYMENT_PAYPAL_PRO_PAYFLOW_EC_TEXT_COMMENTS', 'Comentarios:');
  define('MODULE_PAYMENT_PAYPAL_PRO_PAYFLOW_EC_ERROR_GENERAL', 'Error: Un problema general se ha producido con la transacci&oacute;n. Por favor, int&eacute;ntelo de nuevo.');
  define('MODULE_PAYMENT_PAYPAL_PRO_PAYFLOW_EC_ERROR_CFG_ERROR', 'Error: Error de configuraci&oacute;n con el M&oacute;dulo de Pago. Por favor, verifique las credenciales de acceso.');
  define('MODULE_PAYMENT_PAYPAL_PRO_PAYFLOW_EC_ERROR_ADDRESS', 'Error: La relaci&oacute;n de la Direcci&oacute;n de Env&iacute;o a la Ciudad, Estado y C&oacute;digo Postal ha fallado. Por favor, int&eacute;ntelo de nuevo.');
  define('MODULE_PAYMENT_PAYPAL_PRO_PAYFLOW_EC_ERROR_DECLINED', 'Error: Esta transacci&oacute;n ha sido rechazada. Por favor, int&eacute;ntelo de nuevo.');
  define('MODULE_PAYMENT_PAYPAL_PRO_PAYFLOW_EC_ERROR_EXPRESS_DISABLED', 'Error: El pago expr&eacute;s de PayPal ha sido desactivada para este vendedor. Por favor, p&oacute;ngase en contacto con Servicio al Cliente de PayPal.');
?>
