<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Condiciones de Uso');
define('HEADING_TITLE', 'Condiciones de Uso');

define('TEXT_INFORMATION', 'Inserte aqu&iacute; la informaci&oacute;n de sus condiciones de uso.');
?>
