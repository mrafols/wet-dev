<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ORDER_TOTAL_SHIPPING_TITLE', 'Env&iacute;o');
  define('MODULE_ORDER_TOTAL_SHIPPING_DESCRIPTION', 'Costos de env&iacute;o del pedido');

  define('FREE_SHIPPING_TITLE', 'Env&iacute;o Gratis');
  define('FREE_SHIPPING_DESCRIPTION', 'Env&iacute;o gratuito para pedidos superiores %s');
?>