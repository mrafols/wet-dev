<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Comentarios');

define('TEXT_CLICK_TO_ENLARGE', 'Haga Click para Ampliar');

define('TEXT_OF_5_STARS', '%s de 5 Estrellas!');
?>