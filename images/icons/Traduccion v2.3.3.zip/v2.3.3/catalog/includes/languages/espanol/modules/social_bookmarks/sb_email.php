<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_SOCIAL_BOOKMARKS_EMAIL_TITLE', 'Correo Electr&oacute;nico');
  define('MODULE_SOCIAL_BOOKMARKS_EMAIL_DESCRIPTION', 'Compartir productos v&iacute;a Correo Electr&oacute;nico.');
  define('MODULE_SOCIAL_BOOKMARKS_EMAIL_PUBLIC_TITLE', 'Compartir v&iacute;a Correo Electr&oacute;nico');
?>
