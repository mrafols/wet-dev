<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_IPAYMENT_PP_TEXT_TITLE', 'iPayment (Pago por adelantado)');
  define('MODULE_PAYMENT_IPAYMENT_PP_TEXT_PUBLIC_TITLE', 'Pago por adelantado (Paysafecard)');
  define('MODULE_PAYMENT_IPAYMENT_PP_TEXT_DESCRIPTION', '<img src="images/icon_popup.gif" border="0">&nbsp;<a href="https://www.ipayment.de" target="_blank" style="text-decoration: underline; font-weight: bold;">Visite el Sitio Web de iPayment</a>');
  define('MODULE_PAYMENT_IPAYMENT_PP_ERROR_HEADING', 'Se ha producido un error al procesar su tarjeta de prepago');
  define('MODULE_PAYMENT_IPAYMENT_PP_ERROR_MESSAGE', 'Verifique los detalles de la tarjeta de prepago!');
?>
