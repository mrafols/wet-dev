<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_CURRENCIES_TITLE', 'Monedas');
  define('MODULE_BOXES_CURRENCIES_DESCRIPTION', 'Mostrar Monedas disponibles');
  define('MODULE_BOXES_CURRENCIES_BOX_TITLE', 'Monedas');
?>
