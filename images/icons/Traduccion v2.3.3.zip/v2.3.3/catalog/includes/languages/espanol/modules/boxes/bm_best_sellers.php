<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_BEST_SELLERS_TITLE', 'Los m&aacute;s vendidos');
  define('MODULE_BOXES_BEST_SELLERS_DESCRIPTION', 'Mostrar m&aacute;s vendidos globales y por categor&iacute;a');
  define('MODULE_BOXES_BEST_SELLERS_BOX_TITLE', 'Los m&aacute;s vendidos');
?>
