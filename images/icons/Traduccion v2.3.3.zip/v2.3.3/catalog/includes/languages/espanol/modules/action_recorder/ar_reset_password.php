<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2012 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ACTION_RECORDER_RESET_PASSWORD_TITLE', 'Reinicializar Contrase&ntilde;a de Cliente');
  define('MODULE_ACTION_RECORDER_RESET_PASSWORD_DESCRIPTION', 'Registro de uso de los reinicios de la contrase&ntilde;a de clientes.');
?>
