<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Realizar Pedido');
define('NAVBAR_TITLE_2', 'Confirmaci&oacute;n');

define('HEADING_TITLE', 'Confirmaci&oacute;n de pedido');

define('HEADING_SHIPPING_INFORMATION', 'Informaci&oacute;n del env&iacute;o');
define('HEADING_DELIVERY_ADDRESS', 'Direcci&oacute;n de Entrega');
define('HEADING_SHIPPING_METHOD', 'Forma de Env&iacute;o');
define('HEADING_PRODUCTS', 'Productos');
define('HEADING_TAX', 'Impuestos');
define('HEADING_TOTAL', 'Total');
define('HEADING_BILLING_INFORMATION', 'Datos de Facturaci&oacute;n');
define('HEADING_BILLING_ADDRESS', 'Direcci&oacute;n de Facturaci&oacute;n');
define('HEADING_PAYMENT_METHOD', 'Forma de Pago');
define('HEADING_PAYMENT_INFORMATION', 'Datos del Pago');
define('HEADING_ORDER_COMMENTS', 'Comentarios sobre su pedido');

define('TEXT_EDIT', 'Editar');
?>
