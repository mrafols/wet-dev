<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License

  OsCommerce add-on developed by Fedon Dimopoulos, fedondimopoulos@gmail.com
*/

  define('MODULE_HEADER_TAGS_FAVICON_TITLE', 'Favicon');
  define('MODULE_HEADER_TAGS_FAVICON_DESCRIPTION', 'A&ntilde;adir un favicon a la pesta&ntilde;a de tu Navegador');
?>
