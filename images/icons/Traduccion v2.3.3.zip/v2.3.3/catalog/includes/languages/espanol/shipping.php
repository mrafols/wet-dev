<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Env&iacute;os y Devoluciones');
define('HEADING_TITLE', 'Env&iacute;os y Devoluciones');

define('TEXT_INFORMATION', 'Inserte aqu&iacute; la informaci&iacute;n sobre los Env&iacute;os y Devoluciones');
?>
