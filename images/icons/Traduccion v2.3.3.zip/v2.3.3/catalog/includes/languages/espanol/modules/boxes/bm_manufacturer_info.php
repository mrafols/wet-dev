<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_MANUFACTURER_INFO_TITLE', 'Informaci&oacute;n del Fabricante');
  define('MODULE_BOXES_MANUFACTURER_INFO_DESCRIPTION', 'Mostrar informaci&oacute;n del fabricante en la p&aacute;gina de informaci&oacute;n del producto');
  define('MODULE_BOXES_MANUFACTURER_INFO_BOX_TITLE', 'Informaci&oacute;n del Fabricante');
  define('MODULE_BOXES_MANUFACTURER_INFO_BOX_HOMEPAGE', '%s P&aacute;gina Principal');
  define('MODULE_BOXES_MANUFACTURER_INFO_BOX_OTHER_PRODUCTS', 'Otros productos');
?>
