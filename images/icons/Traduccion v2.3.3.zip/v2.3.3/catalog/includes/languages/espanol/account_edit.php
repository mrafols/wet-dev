<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Mi Cuenta');
define('NAVBAR_TITLE_2', 'Editar Cuenta');

define('HEADING_TITLE', 'Informaci&oacute;n de Mi Cuenta');

define('MY_ACCOUNT_TITLE', 'Mi Cuenta');

define('SUCCESS_ACCOUNT_UPDATED', 'Su cuenta se ha actualizado correctamente.');
?>