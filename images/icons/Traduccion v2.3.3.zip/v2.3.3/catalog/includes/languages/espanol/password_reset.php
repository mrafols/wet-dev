<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2012 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Iniciar Sesi&oacute;n');
define('NAVBAR_TITLE_2', 'Restablecer Contrase&ntilde;a');

define('HEADING_TITLE', 'Restablecer Contrase&ntilde;a');

define('TEXT_MAIN', 'Por favor introduzca una nueva contrase&ntilde;a para su Cuenta.');

define('TEXT_NO_RESET_LINK_FOUND', 'Error: El enlace de restablecimiento de contrase&ntilde;a no se encuentra en nuestros registros, por favor intente de nuevo mediante la generaci&oacute;n de un nuevo enlace.');
define('TEXT_NO_EMAIL_ADDRESS_FOUND', 'Error: la direcci&oacute;n de correo electr&oacute;nico no se encuentra en nuestros registros, por favor, int&eacute;ntelo de nuevo.');

define('SUCCESS_PASSWORD_RESET', 'Su contrase&ntilde;a se ha actualizado correctamente. Por favor Ingrese con su nueva contrase&ntilde;a.');
?>