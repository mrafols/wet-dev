<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_SOCIAL_BOOKMARKS_FACEBOOK_TITLE', 'Facebook');
  define('MODULE_SOCIAL_BOOKMARKS_FACEBOOK_DESCRIPTION', 'Compartir productos con Facebook.');
  define('MODULE_SOCIAL_BOOKMARKS_FACEBOOK_PUBLIC_TITLE', 'Compartir con Facebook');
?>
