<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_PRODUCT_NOTIFICATIONS_TITLE', 'Notificaciones del Producto');
  define('MODULE_BOXES_PRODUCT_NOTIFICATIONS_DESCRIPTION', 'Mostrar notificaciones del producto en la p&aacute;gina de informaci&oacute;n del producto');
  define('MODULE_BOXES_PRODUCT_NOTIFICATIONS_BOX_TITLE', 'Notificaciones');
  define('MODULE_BOXES_PRODUCT_NOTIFICATIONS_BOX_NOTIFY', 'Notifiqueme de cambios de <strong>%s</strong>');
  define('MODULE_BOXES_PRODUCT_NOTIFICATIONS_BOX_NOTIFY_REMOVE', 'No me notifiquen de cambios de <strong>%s</strong>');
?>
