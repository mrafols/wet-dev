<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_PRODUCT_SOCIAL_BOOKMARKS_TITLE', 'Producto de los Marcadores sociales');
  define('MODULE_BOXES_PRODUCT_SOCIAL_BOOKMARKS_DESCRIPTION', 'Mostrar marcadores sociales en la p&aacute;gina de informaci&oacute;n del producto');
  define('MODULE_BOXES_PRODUCT_SOCIAL_BOOKMARKS_BOX_TITLE', 'Compartir Producto');
?>
