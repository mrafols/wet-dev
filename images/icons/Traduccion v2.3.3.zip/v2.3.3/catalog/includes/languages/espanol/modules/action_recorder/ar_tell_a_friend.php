<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ACTION_RECORDER_TELL_A_FRIEND_TITLE', 'Enviar a un Amigo');
  define('MODULE_ACTION_RECORDER_TELL_A_FRIEND_DESCRIPTION', 'Registro de uso de la caracter&iacute;stica de Enviar a un Amigo.');
?>
