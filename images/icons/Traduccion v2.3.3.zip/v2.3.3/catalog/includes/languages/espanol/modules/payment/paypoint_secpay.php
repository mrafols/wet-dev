<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_PAYPOINT_SECPAY_TEXT_TITLE', 'PayPoint.net SECPay');
  define('MODULE_PAYMENT_PAYPOINT_SECPAY_TEXT_PUBLIC_TITLE', 'Tarjeta de Cr&eacute;dito');
  define('MODULE_PAYMENT_PAYPOINT_SECPAY_TEXT_DESCRIPTION', 'Informaci&oacute;n de Prueba de la Tarjeta de Cr&eacute;dito:<br /><br />CC#: 4444333322221111<br />Caducidad: Cualquiera');
  define('MODULE_PAYMENT_PAYPOINT_SECPAY_TEXT_ERROR', 'Error en la Tarjeta de Cr&eacute;dito!');
  define('MODULE_PAYMENT_PAYPOINT_SECPAY_TEXT_ERROR_MESSAGE', 'Se ha producido un error al procesar su Tarjeta de Cr&eacute;dito. Por favor, int&eacute;ntelo de nuevo.');
  define('MODULE_PAYMENT_PAYPOINT_SECPAY_TEXT_ERROR_MESSAGE_N', 'La transacci&oacute;n no estaba autorizada. Por favor, intente otra tarjeta.');
  define('MODULE_PAYMENT_PAYPOINT_SECPAY_TEXT_ERROR_MESSAGE_C', 'Existe un problema de comunicaci&oacute;n con el banco, por favor, int&eacute;ntelo de nuevo.');
?>
