<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Mi Cuenta');
define('NAVBAR_TITLE_2', 'Cambiar Contrase&ntilde;a');

define('HEADING_TITLE', 'Mi Contrase&ntilde;a');

define('MY_PASSWORD_TITLE', 'Mi Contrase&ntilde;a');

define('SUCCESS_PASSWORD_UPDATED', 'Su contrase&ntilde;a ha sido actualizada correctamente.');
define('ERROR_CURRENT_PASSWORD_NOT_MATCHING', 'Su contrase&ntilde;a actual no coincide con la contrase&ntilde;a en nuestros registros. Por favor, int&eacute;ntelo de nuevo.');
?>
