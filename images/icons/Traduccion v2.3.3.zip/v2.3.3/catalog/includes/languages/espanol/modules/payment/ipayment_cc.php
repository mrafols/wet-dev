<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_IPAYMENT_CC_TEXT_TITLE', 'iPayment (Tarjeta de Cr&eacute;dito)');
  define('MODULE_PAYMENT_IPAYMENT_CC_TEXT_PUBLIC_TITLE', 'Tarjeta de Cr&eacute;dito');
  define('MODULE_PAYMENT_IPAYMENT_CC_TEXT_DESCRIPTION', '<img src="images/icon_popup.gif" border="0">&nbsp;<a href="https://www.ipayment.de" target="_blank" style="text-decoration: underline; font-weight: bold;">Visite el Sitio Web de iPayment</a>');
  define('MODULE_PAYMENT_IPAYMENT_CC_ERROR_HEADING', 'Se ha producido un error al procesar su Tarjeta de Cr&eacute;dito');
  define('MODULE_PAYMENT_IPAYMENT_CC_ERROR_MESSAGE', 'Verifique los detalles de la Tarjeta de Cr&eacute;dito!');
  define('MODULE_PAYMENT_IPAYMENT_CC_TEXT_CREDIT_CARD_OWNER', 'Titular de la Tarjeta de Cr&eacute;dito:');
  define('MODULE_PAYMENT_IPAYMENT_CC_TEXT_CREDIT_CARD_NUMBER', 'N&uacute;mero de la Tarjeta de Cr&eacute;dito:');
  define('MODULE_PAYMENT_IPAYMENT_CC_TEXT_CREDIT_CARD_EXPIRES', ' Fecha de caducidad de la Tarjeta de Cr&eacute;dito:');
  define('MODULE_PAYMENT_IPAYMENT_CC_TEXT_CREDIT_CARD_CHECKNUMBER', 'N&uacute;mero de verificaci&oacute;n de la Tarjeta de Cr&eacute;dito:');
?>
