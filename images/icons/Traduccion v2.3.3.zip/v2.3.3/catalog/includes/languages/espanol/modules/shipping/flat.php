<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SHIPPING_FLAT_TEXT_TITLE', 'Tarifa Plana');
define('MODULE_SHIPPING_FLAT_TEXT_DESCRIPTION', 'Tarifa Plana');
define('MODULE_SHIPPING_FLAT_TEXT_WAY', 'Mejor manera');
?>
